<?php

declare(strict_types=1);

namespace Bundle\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CoreBundle extends Bundle
{

}
